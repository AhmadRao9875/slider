<template>
  <div>
    <Slider />
  </div>
</template>

<script>
import Slider from "../src/components/HelloWorld.vue";

export default {
  components: {
    Slider,
  },
};
</script>
